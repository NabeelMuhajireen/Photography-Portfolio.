<?php
// $conn = mysqli_connect('localhost', 'root', '', 'malcolm_db', 4306);


if(isset($_POST['send'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $date = $_POST['date'];
    $plan = $_POST['plan'];
    $location = $_POST['location'];
    $address = $_POST['address'];
    $message = $_POST['message'];

    $insert = "INSERT INTO `contact_form`(`name`, `email`, `number`,`date`,`plan`,`location`,`address`, `message`) 
    VALUES ('$name','$email','$number','$date','$plan','$location',' $address','$message')";

    mysqli_query($conn, $insert);

    header('location:contact.php');

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Contact</title>

        <!-- font awesome cdn link -->
         <link rel="stylesheet" href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css  ">

           <!-- swiper css link -->
           <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
          
         <!-- custom css file link -->
         <link rel="stylesheet" href="css/style.css">


</head>
<body>


<div class="container">

<?php @include 'header.php';  ?>

<section class="contact">

   <h1 class="heading">contact us</h1>

   <form action="" method="post">
    <div class="flex">
      <div class="inputbox">
        <span>Name</span>
        <input type="text" placeholder="enter your name" name="name" required>
      </div>

      <div class="inputbox">
        <span>Email</span>
        <input type="email" placeholder="enter your email" name="email" required>
      </div>

      <div class="inputbox">
        <span>Phone Number</span>
        <input type="number" placeholder="enter your number" name="number" required>
      </div>

      <div class="inputbox">
        <span>Date</span>
        <input type="date" placeholder="enter your date" name="date" required>
      </div>

      <div class="inputbox">
        <span>choose plan</span>
        <select name="plan">
          <option value="nature">Nature Photography</option>
          <option value="sports">Sports Photography</option>
          <option value="wedding">Wedding Photography</option>
          <option value="wedding">Portrait Photography</option>
          <option value="wedding">WildLife Photography</option>
          <option value="wedding">Landscape Photography</option>
          <option value="wedding">Others</option>
        </select>
      </div>

      <div class="inputbox">
        <span>Location</span>
        <input type="location" placeholder="enter your location" name="location" required>
      </div>

      <div class="inputbox">
        <span>Address</span>
        <textarea name="address" placeholder="enter your address" required cols="30" rows="10"></textarea>
      </div>

      <div class="inputbox">
        <span>Message</span>
        <textarea name="message" placeholder="enter your message" required cols="30" rows="10"></textarea>
      </div>

    </div>
    <input type="submit" value="send meesage" name="send" class="btn">
   </form>

</section>

<?php @include 'footer.php';  ?>


<div>













 <!-- custom js link -->
 
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>



 <!-- custom js file link -->
<script src="js/script.js"></script>
</body>
</html>    
