<section class="header">


<a href="home.php" class="logo">Linda's Gallery</a>


<nav class="navbar">
  <a href="home.php">Home</a>
  <a href="about.php">About</a>
  <a href="index.php">portfolio</a>
  <a href="pricing.php">Pricing</a>
  <a href="contact.php">Contact</a>
  
  
  
</nav>

<div id="menu-btn" class="fas fa-bars"></div>


</section>