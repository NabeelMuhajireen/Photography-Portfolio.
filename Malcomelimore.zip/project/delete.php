<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        include 'db.conn.php';

        $imageId = $_POST['image_id'];

        try {
            
            $stmt = $conn->prepare("SELECT img_name FROM images WHERE id = :id");
            $stmt->bindParam(':id', $imageId);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $imageName = $result['img_name'];

           
            $stmt = $conn->prepare("DELETE FROM images WHERE id = :id");
            $stmt->bindParam(':id', $imageId);
            $stmt->execute();

           
            $imagePath = "uploads/" . $imageName;
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }

           
            header("Location: index.php");
            exit();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
} else {
   
    header("Location: index.php");
    exit();
}
?>
