<section class="footer">

<div class="box-container">
    
    <div class="box">
        <h3>Quick links</h3>
        <a href="home.php"> <i class="fas fa-angle-right"></i>Home</a>
        <a href="about.php"> <i class="fas fa-angle-right"></i>About Us</a>
        <a href="index.php"> <i class="fas fa-angle-right"></i>Portfolio</a>
        <a href="pricing.php"> <i class="fas fa-angle-right"></i>Pricing</a>
        <a href="contact.php"> <i class="fas fa-angle-right"></i>Contact</a>
      
    </div>

    <div class="box">
        <h3>Extra links</h3>
        <a href="#"> <i class="fas fa-angle-right"></i>Event Plan</a>
        <a href="#"> <i class="fas fa-angle-right"></i>Our Services</a>
        <a href="#"> <i class="fas fa-angle-right"></i>Ask Questions</a>
        <a href="#"> <i class="fas fa-angle-right"></i>Terms of Service</a>
        <a href="#"> <i class="fas fa-angle-right"></i>Privacy Policy</a>
        
    </div>

    <div class="box">
    <h3>Contact info</h3>
       
        <a href="#"> <i class="fas fa-phone"></i> +947-799-17749</a>
        <a href="#"> <i class="fas fa-phone"></i> +947-444-5543 </a>
        <a href="#"> <i class="fas fa-envelope"></i> billa274@gmail.com </a>
        
        <a href="#"> <i class="fas fa-map"></i>Sri lanka</a>
        
    
    </div>
    <div class="box">
        <h3>follow us </h3>
        <a href="#"> <i class="fab fa-facebook-f"></i> Facebook </a>
        <a href="#"> <i class="fab fa-twitter"></i>  Twitter </a>
        <a href="#"> <i class="fab fa-instagram"></i> Instagram </a>
        <a href="#"> <i class="fab fa-linkedin"></i> Linkedin </a>
        <a href="#"> <i class="fab fa-github"></i> Github </a>
       
</div>

</div>

<p class="credit"> Created by <span>ZenTec</span> | All rights reserved </p>

</section>